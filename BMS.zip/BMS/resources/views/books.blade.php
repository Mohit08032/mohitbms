<form action="{{ route('books') }}" method="GET" class="mb-4">
    <input type="text" name="query" placeholder="Search by title or author" value="{{ request('query') }}" class="form-control">
    <button type="submit" class="btn btn-primary mt-2">Search</button>
</form>
@extends('booklayout')

@section('content')
    <h1>Search Results</h1>

    @if($query)
        <p>Results for "<strong>{{ $query }}</strong>":</p>
    @endif

    @if($books->count())
        <ul class="list-group">
            @foreach($books as $book)
                <li class="list-group-item">
                    <h5>{{ $book->title }}</h5>
                    <p>Author: {{ $book->author }}</p>
                </li>
            @endforeach
        </ul>

        <!-- Pagination Links -->
        <div class="mt-4">
            {{ $books->links() }}
        </div>
    @else
        <p>No books found.</p>
    @endif
@endsection
