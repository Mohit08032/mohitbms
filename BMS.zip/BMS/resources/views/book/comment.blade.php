@extends('layouts.app')

@section('content')
    <h1>{{ $books->title }}</h1>
    <p>Author: {{ $books->author }}</p>
    <p>Description: {{ $books->description }}</p>

    <!-- Display Comments -->
    <h3>Comments</h3>
    <ul class="list-group">
        @foreach($books->comments as $comment)
            <li class="list-group-item">
                <strong>{{ $comment->user->name }}:</strong> {{ $comment->content }}
                <br>
                <small class="text-muted">Posted on {{ $comment->created_at->format('d M Y, H:i') }}</small>
            </li>
        @endforeach
    </ul>

    <!-- Comment Form -->
    @auth
        <form action="{{ route('comments.store', $books->id) }}" method="POST" class="mt-4">
            @csrf
            <textarea name="content" class="form-control" placeholder="Leave a comment..." rows="3" required></textarea>
            <button type="submit" class="btn btn-primary mt-2">Submit</button>
        </form>
    @else
        <p><a href="{{ route('login') }}">Login</a> to leave a comment.</p>
    @endauth
@endsection
