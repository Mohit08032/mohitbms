@extends('layout')

@section('content')
    <h1>{{ $books->title }}</h1>
    <p>Author: {{ $books->author }}</p>
    <p>Rating: {{ $books->rating ?? 'No ratings yet' }} / 5</p>

    <form action="{{ route('books.rate', $books->id) }}" method="POST">
        @csrf
        <label for="rating">Rate this book:</label>
        <select name="rating" id="rating" class="form-control" required>
            <option value="" disabled selected>Select a rating</option>
            @for($i = 1; $i <= 5; $i++)
                <option value="{{ $i }}">{{ $i }} star{{ $i > 1 ? 's' : '' }}</option>
            @endfor
        </select>
        <button type="submit" class="btn btn-primary mt-2">Submit Rating</button>
    </form>
@endsection
