

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($books->title); ?></h1>
    <p>Author: <?php echo e($books->author); ?></p>
    <p>Rating: <?php echo e($books->rating ?? 'No ratings yet'); ?> / 5</p>

    <form action="<?php echo e(route('books.rate', $books->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="rating">Rate this book:</label>
        <select name="rating" id="rating" class="form-control" required>
            <option value="" disabled selected>Select a rating</option>
            <?php for($i = 1; $i <= 5; $i++): ?>
                <option value="<?php echo e($i); ?>"><?php echo e($i); ?> star<?php echo e($i > 1 ? 's' : ''); ?></option>
            <?php endfor; ?>
        </select>
        <button type="submit" class="btn btn-primary mt-2">Submit Rating</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BMS\resources\views/book/show.blade.php ENDPATH**/ ?>