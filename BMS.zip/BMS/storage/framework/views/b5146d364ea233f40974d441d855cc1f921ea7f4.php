<form action="<?php echo e(route('books')); ?>" method="GET" class="mb-4">
    <input type="text" name="query" placeholder="Search by title or author" value="<?php echo e(request('query')); ?>" class="form-control">
    <button type="submit" class="btn btn-primary mt-2">Search</button>
</form>


<?php $__env->startSection('content'); ?>
    <h1>Search Results</h1>

    <?php if($query): ?>
        <p>Results for "<strong><?php echo e($query); ?></strong>":</p>
    <?php endif; ?>

    <?php if($books->count()): ?>
        <ul class="list-group">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <h5><?php echo e($book->title); ?></h5>
                    <p>Author: <?php echo e($book->author); ?></p>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <!-- Pagination Links -->
        <div class="mt-4">
            <?php echo e($books->links()); ?>

        </div>
    <?php else: ?>
        <p>No books found.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('booklayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BMS\resources\views/books.blade.php ENDPATH**/ ?>