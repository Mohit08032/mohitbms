

<?php $__env->startSection('content'); ?>
    <h1><?php echo e($books->title); ?></h1>
    <p>Author: <?php echo e($books->author); ?></p>
    <p>Description: <?php echo e($books->description); ?></p>

    <!-- Display Comments -->
    <h3>Comments</h3>
    <ul class="list-group">
        <?php $__currentLoopData = $books->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item">
                <strong><?php echo e($comment->user->name); ?>:</strong> <?php echo e($comment->content); ?>

                <br>
                <small class="text-muted">Posted on <?php echo e($comment->created_at->format('d M Y, H:i')); ?></small>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <!-- Comment Form -->
    <?php if(auth()->guard()->check()): ?>
        <form action="<?php echo e(route('comments.store', $books->id)); ?>" method="POST" class="mt-4">
            <?php echo csrf_field(); ?>
            <textarea name="content" class="form-control" placeholder="Leave a comment..." rows="3" required></textarea>
            <button type="submit" class="btn btn-primary mt-2">Submit</button>
        </form>
    <?php else: ?>
        <p><a href="<?php echo e(route('login')); ?>">Login</a> to leave a comment.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BMS\resources\views/book/comment.blade.php ENDPATH**/ ?>