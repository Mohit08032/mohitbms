<?php 
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Books;

class BooksController extends Controller
{
    public function search(Request $request)
    {
        $query = $request->input('query');

        // Search for books by title or author
        $books = Books::where('title', 'LIKE', "%{$query}%")
            ->orWhere('author', 'LIKE', "%{$query}%")
            ->paginate(5); // Pagination

            return view('books', compact('books', 'query'));
    }
    public function rating()
    {
        $books = Books::where('id',1)->first();

        // print($books);
        // dd();

        return view('book.show', compact('books'));

    }

    public function rate(Request $request, $id)
    {
        $request->validate([
            'rating' => 'required|integer|min:1|max:5',
        ]);

        $book = Books::find($id);

        // Update the rating
        $book->update([
            'rating' => $request->input('rating'),
        ]);

        return redirect()->back()->with('success', 'Rating submitted successfully!');
    }
}
