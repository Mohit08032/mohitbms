<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Books;
// use App\Models\Comment;

class CommentController extends Controller
{


    public function comment()
    {
        $books = Books::where('id',1)->first();

        // print($books);
        // dd();

        return view('book.comment', compact('books'));

    }
    public function store(Request $request, Books $book)
    {
        $request->validate([
            'content' => 'required|string|max:500',
        ]);

        // Create a new comment
        $book->comments()->create([
            'user_id' => auth()->id(),
            'content' => $request->input('content'),
        ]);

        return redirect()->back()->with('success', 'Comment added successfully!');
    }
}


